﻿using System.Text.RegularExpressions;
using System.Globalization;
using System.Text;
using System.Collections.Generic;

class main()
{
    private static void Main()
    {
        Console.WriteLine("Olá! Esse é um programa simples que irá calcular quantas vezes uma palavra se repetiu dentro de um determinado texto.");
        Console.WriteLine("Digite um texto e irei começar! Caracteres especiais serão removidos. Ex: @, #, $, etc.");
        string texto = Console.ReadLine();

        //Remove os acentos do texto.
        texto = RemoverAcentos(texto);

        //Remove pontuação e caracteres especiais do texto recebido.
        texto = RemoverPontuacaoECaracteresEspeciais(texto);

        //Separa as palavras utilizando um espaço em branco
        List<string> palavras = RealizarSeparacaoPalavras(texto);

        List<Dictionary<string, int>> keyValues = RealizarContagemDasPalavras(palavras);

        foreach(Dictionary<string, int> key in keyValues)
        {
            Console.WriteLine();
            Console.WriteLine("Palavra = {0}, Total = {1}", key.Keys.FirstOrDefault(), key.Values.FirstOrDefault());
        }
    }

    public static string RemoverAcentos(string texto)
    {
        var normalizedString = texto.Normalize(NormalizationForm.FormD);
        var stringBuilder = new StringBuilder(capacity: normalizedString.Length);

        for (int i = 0; i < normalizedString.Length; i++)
        {
            char c = normalizedString[i];
            var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
            if (unicodeCategory != UnicodeCategory.NonSpacingMark)
            {
                stringBuilder.Append(c);
            }
        }

        stringBuilder = stringBuilder.Replace(".", "");
        stringBuilder = stringBuilder.Replace(",", "");

        return stringBuilder
            .ToString()
            .Normalize(NormalizationForm.FormC);
    }

    public static string RemoverPontuacaoECaracteresEspeciais(string texto)
    {
        string textFormatado = Regex.Replace(texto, "[^0-9A-Za-z _-]", "");

        return textFormatado;
    }

    public static List<string> RealizarSeparacaoPalavras(string texto)
    {
        List<string> palavras = texto.Split(" ").ToList();
        return palavras;
    }

    public static List<Dictionary<string, int>> RealizarContagemDasPalavras(List<string> palavras)
    {
        List<Dictionary<string, int>> valores = new List<Dictionary<string, int>>();

        foreach(var item in palavras.ToList())
        {
            int total = palavras.Where(x => x.ToLower() == item.ToLower()).Count();

            string palavraARemover = palavras.Where (x => x == item).FirstOrDefault();

            palavras.RemoveAll(x => x == palavraARemover);

            if (total > 0)
            {
                valores.Add(new Dictionary<string, int>()
                {
                    {
                        item, total
                    }
                });
            }
        }

        return valores;
    }
}