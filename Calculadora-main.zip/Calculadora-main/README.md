# Calculadora
Calculadora no formato Web API desenvolvida em .NET 8.0
